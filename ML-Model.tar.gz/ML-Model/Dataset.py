#Configuration and analysis of dataset to train ML model on
import pandas as pd




Phishing_dataset_path = '/home/korben/Documents/ML-Training/ML-Model/CEAS_08.csv'

phish_data=pd.read_csv(Phishing_dataset_path)
Total_Phishing=round((phish_data['label'] == 0).mean()*100)
print(Total_Phishing)


